async function rememberIncident() {
    const incident = document.getElementById("incident").value.trim();
    const result = document.getElementById("rememberResult");

    if (!incident) {
        result.textContent = "Enter the incident details first.";
        return;
    }

    result.textContent = "Saving...";

    try {
        const response = await fetch("/remember", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({incident})
        });

        const data = await response.json();
        result.textContent = data.status === "remembered"
            ? "Incident saved to Hindsight."
            : "Could not save: " + data.error;
    } catch (error) {
        result.textContent = "Request failed.";
    }
}

async function askIncident() {
    const question = document.getElementById("question").value.trim();
    const answer = document.getElementById("answer");

    if (!question) {
        answer.textContent = "Enter a question first.";
        return;
    }

    answer.textContent = "Checking incident history...";

    try {
        const response = await fetch("/ask", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({question})
        });

        const data = await response.json();
        answer.textContent = data.status === "success"
            ? data.answer
            : "Could not search memory: " + data.error;
    } catch (error) {
        answer.textContent = "Request failed.";
    }
}
