# IncidentMind

IncidentMind is a small internal-style incident response tool built around persistent operational memory.

The idea is simple: when a production issue happens, engineers should be able to reuse what the team learned from previous incidents instead of starting the investigation from scratch.

## What it does

- Stores incident notes using Hindsight
- Searches the team's incident memory
- Uses previous incidents when answering investigation questions
- Provides a lightweight browser interface

## Stack

- Python
- FastAPI
- Hindsight
- Groq through the Hindsight server
- HTML/CSS/JavaScript

## Run locally

Create and activate a virtual environment, then install:

```powershell
python -m pip install -r requirements.txt
```

Start the local Hindsight server separately.

Then run:

```powershell
python -m uvicorn app:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

## Example

Record:

> Payment API returned 503 errors after deployment v2.4.1. The root cause was an incorrect connection pool configuration. The team fixed it by reverting the configuration and restarting the payment service.

Then ask:

> Have we seen a similar Payment API 503 incident before? What caused it and how was it fixed?

The answer should use the incident stored in Hindsight.

## Hindsight

IncidentMind uses Hindsight as its persistent memory layer.

- https://github.com/vectorize-io/hindsight
- https://hindsight.vectorize.io/
- https://vectorize.io/what-is-agent-memory

## Security

Do not commit API keys, `.env` files, virtual environments, or other secrets to GitHub.
